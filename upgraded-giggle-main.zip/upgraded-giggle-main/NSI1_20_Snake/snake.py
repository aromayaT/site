import tkinter as tk
from tkinter import *
import random
from random import randint
from tkinter import font as tkfont
from PIL import Image, ImageTk


# On crée un environnement Tkinter
root = Tk()
im_teteN = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/teteN.png") 
teteN = ImageTk.PhotoImage(im_teteN) 
im_teteS = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/teteS.png") 
teteS = ImageTk.PhotoImage(im_teteS) 
im_teteE = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/teteE.png") 
teteE = ImageTk.PhotoImage(im_teteE) 
im_teteW = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/teteW.png") 
teteW = ImageTk.PhotoImage(im_teteW) 
im_noeud1 = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/noeud1.png") 
noeud1 = ImageTk.PhotoImage(im_noeud1) 
im_noeud2 = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/noeud2.png") 
noeud2 = ImageTk.PhotoImage(im_noeud2)
pomme = Image.open("C:/Users/giantayamora/Snake/NSI1_20_Snake_sources_eleves/assets/pomme.png") 
pomme = ImageTk.PhotoImage(pomme)


def right(event):
    global direction, previous_direction
    if previous_direction != 'left':
        direction = 'right'

def left(event):
    global direction, previous_direction
    if previous_direction != 'right':
        direction = 'left'
    
def down(event):
    global direction, previous_direction
    if previous_direction != 'up':
        direction = 'down'
    
def up(event):
    global direction, previous_direction
    if previous_direction != 'down':
        direction = 'up'
        

def computeNextFrame(numFrame, coordonnee, objet):
    global direction, previous_direction, score, quiz, quiz_visible, quiz_timer
    #Affiche le numéro de la frame
    numFrame += 1
    game_over = False
    
    can.delete('all')
    

    
        #Propagation du déplacement des noeuds
    for n in range(len(coordonnee)-1, 0, -1):
        coordonnee[n][0] = coordonnee[n-1][0]
        coordonnee[n][1] = coordonnee[n-1][1]
        
    #Mise à jour des coordonnees
    if direction == 'right':
        coordonnee[0][0] += 20
        can.create_image(coordonnee[0][0], coordonnee[0][1], anchor = NW, image = teteE)
    elif direction == 'left':
        coordonnee[0][0] -= 20
        can.create_image(coordonnee[0][0], coordonnee[0][1], anchor = NW, image = teteW)
    elif direction == 'up':
        coordonnee[0][1] -= 20
        can.create_image(coordonnee[0][0], coordonnee[0][1], anchor = NW, image = teteN)
    elif direction == 'down':
        coordonnee[0][1] += 20
        can.create_image(coordonnee[0][0], coordonnee[0][1], anchor = NW, image = teteS)
        
    previous_direction = direction 
    

    #Detection collision avec les bords
    if (coordonnee[0][0] < 0 or coordonnee[0][0] >= 500 or
        coordonnee[0][1] < 0 or coordonnee[0][1] >= 500):
        game_over = True 

    #Apparition de l'item
    if not quiz_visible and randint(1, 100) <= 2:
        x = randint(1, 24) * 20
        y = randint(1, 24) * 20
        quiz = [x, y]
        quiz_visible = True
        quiz_timer = 0
    
    #Affichage de l'item
    if quiz_visible:
        can.create_oval(quiz[0], quiz[1], quiz[0] + 20, quiz[1] + 20, fill = "yellow") 
        if coordonnee[0][0] == quiz[0] and coordonnee[0][1] == quiz[1]:
            quiz_visible = False
            quiz = None
            question()
        
        else:
            quiz_timer += 1
            if quiz_timer >= 35:
                quiz_visible = False
                quiz = None
                game_over = True
        
    can.create_image(coordonnee[0][0], coordonnee[0][1], anchor = NW, image = noeud1)
                         
    for p in range(1, len(coordonnee)):
        can.create_image(coordonnee[p][0], coordonnee[p][1], anchor = NW, image = noeud2)
                             
    
    for p in range(len(objet)):
        can.create_image(objet[p][0], objet[p][1], anchor = NW, image = pomme)
                                 
    for p in range(len(objet)):
        if coordonnee[0][0] == objet [0][0] and coordonnee and coordonnee[p][1] == objet[p][1]:
            #Déplacement de la pomme
            objet[0][0] = randint(1, 24) * 20
            objet[0][1] = randint(1, 24) * 20
            coordonnee.append([-20, -20])
            score += 1
            

    #On teste la position de la tête par rapport aux noeuds du serpent
    for n in range(1, len(coordonnee)):
        if coordonnee[0][0] == coordonnee[n][0] and coordonnee[p][1] == coordonnee[n][1]:
            game_over = True
           
           
    can.create_text(50, 10, text = f"Score : {score}", fill = "white", font = ("Helvetica", 12))
    if game_over:
        TEXTE = "GAME OVER"
        normal_font = tkfont.Font(family = "Helvetica", size = 12, weight = "bold")
        can.create_text(100, 200, text = TEXTE, fill = "red", font = normal_font)

    else:
        root.after(100, lambda:computeNextFrame(numFrame, coordonnee, objet))


def question():
    global score, game_over
    
    question, correct = random.choice(questions)
    
    fenetre = Toplevel(root)
    fenetre.title("Vrai ou Faux")
    Label(fenetre, text = question, font = ("Arial", 12)).pack(pady=5)
    
    def reponse(choix):
        if choix == correct:
            tk.Label(fenetre, text = "Bonne réponse ! +1 point", fg = "green").pack()
            global score
            score += 1
        else :
            game_over = True
            if correct :
                bonne = "Vrai"
            else :
                bonne = "Faux"

            tk.Label(fenetre, text = f"Mauvaise réponse. C'était : {bonne}", fg = "red").pack()

        fenetre.after(2000, fenetre.destroy)


    tk.Button(fenetre, text = "Vrai", command = lambda : reponse(True)).pack(pady = 5)
    tk.Button(fenetre, text = "Faux", command = lambda : reponse(False)).pack(pady = 5)
    


if __name__ == "__main__":
    
    direction = 'up'
    previous_direction = direction
    
    can = Canvas(root, width = 500, height = 500, bg = 'black')
    can.pack()
    
    quiz = None
    quiz_visible = False
    quiz_timer = 0
    
    score = 0
    
    game_over = False

    coordonnee = [[200, 200], [200, 220], [200, 240], [220, 240]]
    objet = []
    
    #Premier objet (la pomme)
    x = randint(1, 24)
    y = randint(1, 24)
    objet.append([x*20, y*20, 0])

    computeNextFrame(0, coordonnee, objet)
    
    root.bind('<d>', right)
    root.bind('<q>', left)
    root.bind('<s>', down)
    root.bind('<z>', up)
    
    questions = [
    ("La Terre est plate", False),
    ("5 x 6 = 30", True),
    ("Le soleil tourne autour de la Terre", False),
    ("Python est un langage de programmation", True),
    ("L'eau bout à 100 degrés Celsius", True),
    ("La France est en Amérique du Sud", False),
    ("2 + 2 = 5", False),
    ("La racine carrée de 49 est 7", True),
    ("Un carré a trois côtés", False),
    ("Pi est approximativement égal à 3.14", True),
    ("Un nombre pair est divisible par 2", True),
    ("L’Amazonie est une forêt située en Afrique", False),
    ("La Tour Eiffel est à Paris", True),
    ("Le mont Everest est la plus haute montagne du monde", True),
    ("La mer Morte est plus salée que l'océan", True),
    ("L’humain a 4 poumons", False),
    ("Le requin est un mammifère", False),
]

    
    tk.mainloop()

